// -----------------------------------------------------------------------------
#ifndef CIRCLE_H_
#define CIRCLE_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Shape.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct Circle : Shape
	{
		Circle(Point p, int rr)	// center and radius
			:r{ rr }
			, diameter(rr * 2)
		{
			add(Point{ p.x - r, p.y - r });
		}

		void draw_lines() const;

		Point center() const { return { point(0).x + r, point(0).y + r }; }
		Point getPointOnCircle(double angle) const;

		Point getPointDirection(Directions d);

		void set_radius(int rr) { r = rr; }
		int radius() const { return r; }
		int diam() const { return diameter; }
	private:
		int r;
		int diameter;
	};

	// -----------------------------------------------------------------------------

	struct Immobile_circle : Circle
	{
		Immobile_circle(Point p, int radius)
			: Circle(p, radius)
		{}

	private:
		using Circle::set_point;
		using Circle::move;
	};

	// -----------------------------------------------------------------------------

	struct Striped_circle : Circle
	{
		Striped_circle(Point p, int radius, int stripeW = 1, Color stripeC = Color::black)
			: Circle(p, radius)
			, m_stripeCol(stripeC)
			, m_stripeWidth(stripeW)
		{
			validateCircle();
			set_fill_color(m_stripeCol);
		}

		void draw_lines() const;

	private:
		void validateCircle();
		Color m_stripeCol;
		int m_stripeWidth;
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !CIRCLE_H_
