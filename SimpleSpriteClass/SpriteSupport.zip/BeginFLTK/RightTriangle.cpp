// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "RightTriangle.h"

#include "fltk.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	//------------------------------------------------------------------------------

	void RightTriangle::rightTriangleTileWindow(vector<RightTriangle>& v, int sideLength)
	{
		RightTriangle rt1(Point(0, 0), Point(0, sideLength), Point(sideLength, sideLength), Color::black, Color::black);
		RightTriangle rt2(Point(0, 0), Point(sideLength, 0), Point(sideLength, sideLength), Color::cyan, Color::cyan);

		for (int y = 0; y < Fl::y(); y += sideLength)
		{
			for (int x = 0; x < Fl::x(); x += sideLength)
			{
				rt1.set_point(0, Point(x, y));
				rt1.set_point(1, Point(x, y + sideLength));
				rt1.set_point(2, Point(x + sideLength, y + sideLength));

				rt2.set_point(0, Point(x, y));
				rt2.set_point(1, Point(x + sideLength, y));
				rt2.set_point(2, Point(x + sideLength, y + sideLength));

				v.push_back(rt1);
				v.push_back(rt2);
			}
		}
	}

	// -----------------------------------------------------------------------------

	// ensure that all the angles add up to 180 and one of them is 90.
	// abs() flips int negatives to positive
	void RightTriangle::validateTriangle(Point p1, Point p2, Point p3)
	{
		a1 = findAngleBetween2Lines(p1, p2, p1, p3);
		a2 = findAngleBetween2Lines(p1, p2, p2, p3);
		a3 = findAngleBetween2Lines(p2, p3, p1, p3);
		int totalAngles = int(a1 + a2 + a3);
		if (totalAngles != 180)
			error("All the angles in a right-triangle should add up to 180. This one adds up to " + totalAngles);
		if (a1 != 90 && a2 != 90 && a3 != 90)
			error("One of the angles must be equal to 90 degrees.");
	}

	//------------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------