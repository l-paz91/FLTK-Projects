// -----------------------------------------------------------------------------
#ifndef SHAPE_H_
#define SHAPE_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Graph.h"

#include "Point.h"
#include <FL/fl_draw.H>

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// deals with color and style, and holds sequence of lines
	class Shape
	{
	protected:
		Shape() { set_color(Color::black); }

		// add() the Points to this Shape
		Shape(initializer_list<Point> p)
			: points(p)
		{}

		void add(Point p) { points.push_back(p); }

	public:
		void draw() const;					// deal with color and draw_lines
	protected:
		virtual void draw_lines() const;	// simply draw the appropriate lines
	public:
		virtual void move(int dx, int dy);	// move the shape +=dx and +=dy
		void set_point(int i, Point p) { points[i] = p; }
		void set_color(Color col) { lcolor = col; }
		Color color() const { return lcolor; }
		void setLineVisibility(bool visbility) { lcolor.set_visibility(visbility); }

		void set_style(Line_style sty) { ls = sty; }
		Line_style style() const { return ls; }

		void setFillVisibility(bool visibility) { fcolor.set_visibility(visibility); }
		void set_fill_color(Color col) { fcolor = col; }
		Color fill_color() const { return fcolor; }

		Point point(int i) const { return points[i]; }
		int number_of_points() const { return points.size(); }
		//clears all the points in a shape
		void resetPoints() { points.clear(); }

		enum Directions {
			N, S, E, W, CENTER, NE, SE, SW, NW
		};
		virtual Point getPointDirection(Directions d);

		virtual ~Shape() { }
	private:
		vector<Point> points;	// not used by all shapes
		Color lcolor{ fl_color() };
		Line_style ls{ 0 };
		Color fcolor{ Color::invisible };
	};

	// -----------------------------------------------------------------------------

	pair<double, double> line_intersect(Point p1, Point p2, Point p3, Point p4, bool& parallel);
	bool line_segment_intersect(Point p1, Point p2, Point p3, Point p4, Point& intersection);

	// -----------------------------------------------------------------------------



}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !SHAPE_H_