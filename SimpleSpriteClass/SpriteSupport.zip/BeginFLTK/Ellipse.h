// -----------------------------------------------------------------------------
#ifndef ELLIPSE_H_
#define ELLIPSE_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Shape.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct Ellipse : Shape
	{
		Ellipse(Point p, int ww, int hh)	// center, min, and max distance from center
			:w{ ww }, h{ hh } {
			add(Point{ p.x - ww, p.y - hh });
		}

		void draw_lines() const;
		Point getPointOnEllipse(int angle);
		Point getPointDirection(Directions d);

		Point center() const { return{ point(0).x + w, point(0).y + h }; }
		Point focus1() const { return{ center().x + int(sqrt(double(w*w - h * h))), center().y }; }
		Point focus2() const { return{ center().x - int(sqrt(double(w*w - h * h))), center().y }; }

		void set_major(int ww) { w = ww; }
		int major() const { return w; }
		void set_minor(int hh) { h = hh; }
		int minor() const { return h; }
	private:
		int w;
		int h;
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !ELLIPSE_H_
