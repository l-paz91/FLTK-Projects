// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "ClosedPolyline.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	//------------------------------------------------------------------------------

	void Closed_polyline::draw_lines() const
	{
		Open_polyline::draw_lines();

		if (color().visibility())	// draw closing line:
			fl_line(int(point(number_of_points() - 1).x), int(point(number_of_points() - 1).y), int(point(0).x), int(point(0).y));
	}

	//------------------------------------------------------------------------------

	void Striped_closed_polyline::draw_lines() const
	{
		//determine a bounding box for the polygon (this gives us the stripes)
		double xMin = point(0).x; double yMin = point(0).y;
		double xMax = point(0).x;  double yMax = point(0).y;
		for (int i = 0; i < number_of_points(); ++i)
		{
			if (point(i).x < xMin)
				xMin = point(i).x;
			if (point(i).x > xMax)
				xMax = point(i).x;
			if (point(i).y < yMin)
				yMin = point(i).y;
			if (point(i).y > yMax)
				yMax = point(i).y;
		}
		const int width = int(xMax) - int(xMin);
		const int height = int(yMax) - int(yMin);

		const int numOfLines = (width / m_stripeWidth) / 2;
		double x = xMin;
		double y = yMin;
		Point intersect;
		vector<Point> in;
		int intersectCount = 0;
		for (int i = 0; i < numOfLines; ++i)
		{
			//does the stripe hit one of the lines?
			for (int n = 0; n < number_of_points() - 1; ++n)
			{
				if (line_segment_intersect(Point{ x, y }, Point{ x, y + height },
					Point{ point(n).x, point(n).y }, Point{ point(n + 1).x, point(n + 1).y }, intersect))
				{
					if (intersectCount < 2)
					{
						in.push_back(intersect);
						++intersectCount;		//we only want to pushback 2 intersects for any given line
					}
				}
			}
			x += 2;	//skip to the next line
			intersectCount = 0;
		}

		//match up the intersects
		fl_color(fill_color().as_int());
		for (uint32 i = 0; i < in.size() - 1; i += 2)
			fl_line(int(in[i].x), int(in[i].y), int(in[i + 1].x), int(in[i + 1].y));

		//outline colour
		if (color().visibility())
			Shape::draw_lines();
	}

	//------------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------