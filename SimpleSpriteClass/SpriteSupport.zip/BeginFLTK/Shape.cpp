// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Shape.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------
	
	void Shape::draw_lines() const
	{
		if (color().visibility() && 1 < points.size())	// draw sole pixel?
			for (uint32 i = 1; i < points.size(); ++i)
				fl_line(int(points[i - 1].x), int(points[i - 1].y), int(points[i].x), int(points[i].y));
	}

	//------------------------------------------------------------------------------

	void Shape::draw() const
	{
		Fl_Color oldc = fl_color();
		// there is no good portable way of retrieving the current style
		fl_color(lcolor.as_int());
		fl_line_style(ls.style(), ls.width());
		draw_lines();
		fl_color(oldc);	// reset color (to pevious) and style (to default)
		fl_line_style(0);
	}

	// -----------------------------------------------------------------------------

	Point Shape::getPointDirection(Directions d)
	{
		if (points.size() == 0)
		{
			error("This shape has no points");
			return Point(0, 0);
		}
		else if (points.size() == 1)
		{
			error("If the shape has more than 1 point, it should override this function with it's own code.");
			return Point(0, 0);
		}
		else
			return points[0];
	}

	// -----------------------------------------------------------------------------

	void Shape::move(int dx, int dy)
	{
		for (unsigned int i = 0; i < points.size(); ++i)
		{
			points[i].x += dx;
			points[i].y += dy;
		}
	}

	// -----------------------------------------------------------------------------

	// helper functions
	// does two lines (p1,p2) and (p3,p4) intersect?
	// if se return the distance of the intersect point as distances from p1
	inline pair<double, double> line_intersect(Point p1, Point p2, Point p3, Point p4, bool& parallel)
	{
		double x1 = p1.x;
		double x2 = p2.x;
		double x3 = p3.x;
		double x4 = p4.x;
		double y1 = p1.y;
		double y2 = p2.y;
		double y3 = p3.y;
		double y4 = p4.y;

		double denom = ((y4 - y3)*(x2 - x1) - (x4 - x3)*(y2 - y1));
		if (denom == 0) {
			parallel = true;
			return pair<double, double>(0, 0);
		}
		parallel = false;
		return pair<double, double>(((x4 - x3)*(y1 - y3) - (y4 - y3)*(x1 - x3)) / denom,
			((x2 - x1)*(y1 - y3) - (y2 - y1)*(x1 - x3)) / denom);
	}

	//------------------------------------------------------------------------------

	//intersection between two line segments
	//Returns true if the two segments intersect,
	//in which case intersection is set to the point of intersection
	bool line_segment_intersect(Point p1, Point p2, Point p3, Point p4, Point& intersection)
	{
		bool parallel;
		pair<double, double> u = line_intersect(p1, p2, p3, p4, parallel);
		if (parallel || u.first < 0 || u.first > 1 || u.second < 0 || u.second > 1) return false;
		intersection.x = p1.x + static_cast<int>(u.first*(p2.x - p1.x));
		intersection.y = p1.y + static_cast<int>(u.first*(p2.y - p1.y));

		return true;
	}

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------