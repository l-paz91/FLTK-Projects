// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Text.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	//------------------------------------------------------------------------------

	void Text::draw_lines() const
	{
		int ofnt = fl_font();
		int osz = fl_size();

		//set font colour
		fl_color(color().as_int());	// reset color
		fl_font(fnt.as_int(), fnt_sz);
		fl_draw(lab.c_str(), int(point(0).x), int(point(0).y));
		fl_font(ofnt, osz);
	}

	// -----------------------------------------------------------------------------

	void TextBox::draw_lines() const
	{
		box.draw_lines();

		Text::draw_lines();
	}

	// -----------------------------------------------------------------------------

	void TextBox::setColours(Color boxOutline, Color boxFill, Color textColor)
	{
		box.set_color(boxOutline);
		box.set_fill_color(boxFill);
		set_color(textColor);
	}

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------