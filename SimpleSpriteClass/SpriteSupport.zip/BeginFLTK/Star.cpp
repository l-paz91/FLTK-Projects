// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Star.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	//------------------------------------------------------------------------------

	Star::Star(Point center, double outerRadius, double innerRadius, double startAngle, int numOfPoints)
		: m_center(center)
	{
		if (numOfPoints < 4)
			error("Cannot have less than 4 points on a star");

		int doubleNumPoints = numOfPoints * 2;
		double angle = 360.0f / doubleNumPoints;
		double rotation = startAngle;
		bool flipflop = true;

		for (int i = 0; i < doubleNumPoints; ++i)
		{
			if (flipflop)
				add(getPointOnStar(int(rotation), outerRadius));
			else
				add(getPointOnStar(int(rotation), innerRadius));

			rotation += angle;
			flipflop = !flipflop;
		}
	}

	// -----------------------------------------------------------------------------

	Point Star::getPointOnStar(int angle, double radius)
	{
		Point p;
		double rad = angle * (PI / 180.0f);
		p.x = radius * cos(rad) + (m_center.x);
		p.y = radius * sin(rad) + (m_center.y);
		return p;
	}

	//------------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------