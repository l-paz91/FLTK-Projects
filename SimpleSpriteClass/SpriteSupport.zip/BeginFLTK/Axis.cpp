// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Axis.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	//------------------------------------------------------------------------------

	Axis::Axis(Orientation d, Point xy, int length, int n, string lab)
		: m_xy(xy)
		, label(Point(0, 0), lab)
		, m_numNotches(n)
		, m_length(length)
		, m_o(d)
	{
		if (length < 0) error("bad axis length");
		switch (d)
		{
		case Axis::x:
		{	Shape::add(xy);	// axis line
		Shape::add(Point(xy.x + length, xy.y));	// axis line
		if (1 < n) {
			int dist = length / n;
			int x = int(xy.x) + dist;
			for (int i = 0; i < n; ++i)
			{
				notches.add(Point(x, xy.y), Point(x, xy.y - 5));
				x += dist;
			}
		}
		// label under the line
		label.move(length / 3, int(xy.y) + 20);
		break;
		}
		case Axis::y:
		{
			Shape::add(xy);	// a y-axis goes up
			Shape::add(Point(xy.x, xy.y - length));
			if (1 < n)
			{
				int dist = length / n;
				int y = int(xy.y) - dist;
				for (int i = 0; i < n; ++i) {
					notches.add(Point(xy.x, y), Point(xy.x + 5, y));
					y -= dist;
				}
			}
			// label at top
			label.move(int(xy.x) - 10, int(xy.y) - length - 10);
			break;
		}
		case Axis::z:
			error("z axis not implemented");
		}
	}

	//------------------------------------------------------------------------------

	void Axis::draw_lines() const
	{
		// the line
		Shape::draw_lines();

		// the notches may have a different color from the line
		notches.draw();	

		// the label may have a different color from the line
		label.draw();
	}

	//------------------------------------------------------------------------------

	void Axis::set_color(Color c)
	{
		Shape::set_color(c);
		notches.set_color(c);
		label.set_color(c);
	}

	// -----------------------------------------------------------------------------

	void Axis::setNotches(Orientation d)
	{
		switch (d)
		{
		case Axis::x:
		{
			if (1 < m_numNotches)
			{
				double dist = (m_length / double(m_numNotches));
				double x = m_xy.x + dist;
				for (double i = 0; i < m_numNotches; ++i)
				{
					notches.add(Point(x, m_xy.y), Point(x, m_xy.y - 5));
					x += dist;
				}
			}
			break;
		}
		case Axis::y:
		{
			if (1 < m_numNotches)
			{
				double dist = (m_length / double(m_numNotches));
				double y = m_xy.y - dist;
				for (double i = 0; i < m_numNotches; ++i)
				{
					notches.add(Point(m_xy.x, y), Point(m_xy.x + 5, y));
					y -= dist;
				}
			}
			break;
		}
		case Axis::z:
			error("z axis not implemented");
		}
	}

	//------------------------------------------------------------------------------

	void Axis::move(int dx, int dy)
	{
		Shape::move(dx, dy);
		notches.move(dx, dy);
		label.move(dx, dy);
	}

	//------------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------