// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Box.h"

#include "Line.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	//------------------------------------------------------------------------------

	void Box::draw_lines() const
	{
		const int radius = round >> 1;
		const int lineW = w - round;
		const int lineH = h - round;

		Point arc1(point(0).x, point(0).y);
		Point arc2(point(0).x + lineW, point(0).y);
		Point arc3(point(0).x + lineW, point(0).y + lineH);
		Point arc4(point(0).x, point(0).y + lineH);

		Line l1(Point{ arc1.x + radius, arc1.y }, Point{ arc2.x + radius, arc2.y });
		Line l2(Point{ arc2.x + round, arc2.y + radius }, Point{ arc2.x + round, arc3.y + radius });
		Line l3(Point{ arc2.x + radius, arc3.y + round }, Point{ arc4.x + radius, arc4.y + round });
		Line l4(Point{ arc4.x, arc4.y + radius }, Point(arc4.x, arc1.y + radius));

		if (fill_color().visibility())
		{	// fill
			fl_color(fill_color().as_int());
			fl_pie(int(arc1.x), int(arc1.y), round, round, 90, 180);
			fl_pie(int(arc2.x), int(arc2.y), round, round, 0, 90);
			fl_pie(int(arc3.x), int(arc3.y), round, round, 270, 360);
			fl_pie(int(arc4.x), int(arc4.y), round, round, 180, 270);

			fl_rectf(int(arc1.x), int(arc1.y) + radius, radius, lineH);
			fl_rectf(int(arc1.x) + radius, int(arc1.y), lineW, h);
			fl_rectf(int(arc2.x) + radius, int(arc2.y) + radius, radius, lineH);
			fl_color(color().as_int());	// reset color
		}

		if (color().visibility())
		{
			//top left-hand corner (arc)
			fl_arc(int(arc1.x), int(arc1.y), round, round, 90, 180);
			//top horizontal line
			fl_line(int(l1.point(0).x), int(l1.point(0).y), int(l1.point(1).x), int(l1.point(1).y));

			//top right-hand corner (arc)
			fl_arc(int(arc2.x), int(arc2.y), round, round, 0, 90);
			//right-hand vertical line
			fl_line(int(l2.point(0).x), int(l2.point(0).y), int(l2.point(1).x), int(l2.point(1).y));

			//bottom right-hand corner (arc)
			fl_arc(int(arc3.x), int(arc3.y), round, round, 270, 360);
			//bottom vertical line
			fl_line(int(l3.point(0).x), int(l3.point(0).y), int(l3.point(1).x), int(l3.point(1).y));

			//bottom left-hand corner (arc)
			fl_arc(int(arc4.x), int(arc4.y), round, round, 180, 270);
			//left-hand vertical line
			fl_line(int(l4.point(0).x), int(l4.point(0).y), int(l4.point(1).x), int(l4.point(1).y));
		}
	}

	//------------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------