// -----------------------------------------------------------------------------
#ifndef ARROW_H_
#define ARROW_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Shape.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct Arrow : Shape
	{
		Arrow(Point from, Point to, int ArrowSize)
			: arrowSize(ArrowSize)
		{
			add(from);
			add(to);
		}

		void draw_lines() const;
		void moveArrow(Point from, Point to) { set_point(0, from); set_point(1, to); }
		void changeArrowSize(int ArrowSize) { arrowSize = ArrowSize; }

	private:
		int arrowSize;
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !ARROW_H_
