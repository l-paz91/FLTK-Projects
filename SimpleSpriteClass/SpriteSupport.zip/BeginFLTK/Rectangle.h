// -----------------------------------------------------------------------------
#ifndef RECTANGLE_H_
#define RECTANGLE_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Shape.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct Rectangle : Shape
	{
		Rectangle(Point xy, double ww, double hh) :w{ ww }, h{ hh }
		{
			if (h <= 0 || w <= 0) error("Bad rectangle: non-positive side");
			add(xy);
		}
		Rectangle(Point x, Point y) :w{ y.x - x.x }, h{ y.y - x.y }
		{
			if (h <= 0 || w <= 0) error("Bad rectangle: first point is not top left");
			add(x);
		}

		void draw_lines() const;

		Point getPointDirection(Directions d);

		double height() const { return h; }
		double width() const { return w; }
	private:
		double h;			// height
		double w;			// width
	//	Color fcolor;		// fill color; 0 means "no fill"
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !RECTANGLE_H_