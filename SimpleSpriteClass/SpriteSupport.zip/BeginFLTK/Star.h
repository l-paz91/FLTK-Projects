#ifndef STAR_H_
#define STAR_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "ClosedPolyline.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct Star : Closed_polyline
	{
		Star(Point center, double outerRadius, double innerRadius, double startAngle = 0, int numOfPoints = 5);

		Point getPointOnStar(int angle, double radius);
		void add(Point p) { Closed_polyline::add(p); }
		void draw_lines() const { Closed_polyline::draw_lines(); }

	private:
		Point m_center;
		double m_radius;
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !STAR_H_

