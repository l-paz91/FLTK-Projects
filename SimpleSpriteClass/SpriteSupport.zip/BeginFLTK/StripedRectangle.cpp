// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "StripedRectangle.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	void Striped_rectangle::validateRect()
	{
		if (m_stripeWidth > width())
			error("Stripe width cannot be more than width.");
		if (m_stripeWidth < 1)
			error("Stripe width must be at least 1 pixel wide.");
	}

	// -----------------------------------------------------------------------------

	void Striped_rectangle::draw_lines() const
	{
		//striped fill
		//how many lines can we have?
		const int numOfLines = (int(width()) / m_stripeWidth) / 2;
		int x = int(point(0).x) + m_stripeWidth;
		int y = int(point(0).y);
		for (int i = 0; i < numOfLines; ++i)
		{
			fl_color(fill_color().as_int());
			fl_line_style(Line_style::solid, m_stripeWidth);	//only set the line style for the fill
			fl_line(x, y, x, y + int(height()));
			x += m_stripeWidth * 2;
		}

		//outline
		if (color().visibility())
		{	// edge on top of fill
			fl_color(color().as_int());
			fl_rect(int(point(0).x) - 1, int(point(0).y), int(width()) + 1, int(height()) + 1);	//-+1 to make outline 1px outside bounding bpx
		}
	}

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------