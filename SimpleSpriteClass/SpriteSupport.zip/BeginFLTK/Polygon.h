// -----------------------------------------------------------------------------
#ifndef POLYGON_H_
#define POLYGON_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "ClosedPolyline.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	// closed sequence of non-intersecting lines
	struct Polygon : Closed_polyline
	{
		using Closed_polyline::Closed_polyline;

		Polygon() {}

		void add(Point p);
		void draw_lines() const;
	};

	// -----------------------------------------------------------------------------

	//open sequence of lines, first and last point must meet up
	//supports any type of polygon i.e complex, convex, regular/irregular
	//however, it only errors if less than 3 points are supplied or the points don't
	//meet up
	struct Poly : Open_polyline
	{
		using Open_polyline::Open_polyline;
		Poly() {}
		Poly(initializer_list<Point> p)
			: Open_polyline(p)
		{
			validatePoly();
		}

		void draw_lines() const { Open_polyline::draw_lines(); }

	private:
		void validatePoly();
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !POLYGON_H_