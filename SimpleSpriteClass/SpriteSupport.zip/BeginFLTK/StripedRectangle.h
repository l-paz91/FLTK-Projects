// -----------------------------------------------------------------------------
#ifndef STRIPEDRECTANGLE_H_
#define STRIPEDRECTANGLE_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Rectangle.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct Striped_rectangle : Rectangle
	{
		Striped_rectangle(Point xy, double width, double height, int stripeW = 1, Color c = Color::black)
			: Rectangle(xy, width, height)
			, m_stripeWidth(stripeW)
			, m_stripeCol(c)
		{
			validateRect();
			set_fill_color(m_stripeCol);
		}

		Striped_rectangle(Point x, Point y, int stripeW = 1, Color c = Color::black)
			: Rectangle(x, y)
			, m_stripeWidth(stripeW)
			, m_stripeCol(c)
		{
			validateRect();
			set_fill_color(m_stripeCol);
		}

		void draw_lines() const;

	private:
		void validateRect();
		Color m_stripeCol;
		int m_stripeWidth;
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !STRIPEDRECTANGLE_H_