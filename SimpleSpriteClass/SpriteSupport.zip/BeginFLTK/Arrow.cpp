// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Arrow.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	//------------------------------------------------------------------------------
	
	void Arrow::draw_lines() const
	{
		double halfA = arrowSize / 2;
		Point p1(point(0).x, point(0).y);	//begin line
		Point p2(point(1).x, point(1).y);	//tip of arrow

		//distance from p1 to p2
		double distance = sqrt(pow((p2.x - p1.x), 2) + pow((p2.y - p1.y), 2));
		//arrow size distance away from p2
		Point p3(halfA / distance * p1.x + (1 - halfA / distance)*p2.x,
			halfA / distance * p1.y + (1 - halfA / distance)*p2.y);		//mid base of arrow

		//'left' arrow point
		int lx = int(p3.x + ((halfA * (p2.y - p1.y)) / distance));
		int ly = int(p3.y + ((halfA * (p1.x - p2.x)) / distance));

		//'right' arrow point
		int rx = int(p3.x + ((halfA * (p1.y - p2.y)) / distance));
		int ry = int(p3.y + ((halfA * (p2.x - p1.x)) / distance));

		if (fill_color().visibility())
		{
			// fill
			fl_color(fill_color().as_int());
			fl_begin_complex_polygon();
			fl_vertex(p2.x, p2.y);
			fl_vertex(lx, ly);
			fl_vertex(rx, ry);
			fl_end_complex_polygon();
			fl_color(color().as_int());	// reset color
		}

		if (color().visibility())
		{
			//lines
			fl_line(int(p1.x), int(p1.y), int(p3.x), int(p3.y));
			fl_line(lx, ly, rx, ry);
			fl_line(int(p2.x), int(p2.y), rx, ry);
			fl_line(lx, ly, int(p2.x), int(p2.y));
		}
	}

	//------------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------