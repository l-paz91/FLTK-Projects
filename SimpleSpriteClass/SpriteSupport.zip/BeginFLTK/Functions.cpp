// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Functions.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	//------------------------------------------------------------------------------

	Function::Function(Fct f, double r1, double r2, Point xy, int count, double xscale, double yscale)
		// graph f(x) for x in [r1:r2) using count line segments with (0,0) displayed at xy
		// x coordinates are scaled by xscale and y coordinates scaled by yscale
	{
		if (r2 - r1 <= 0) error("bad graphing range");
		if (count <= 0) error("non-positive graphing count");
		double dist = (r2 - r1) / count;
		double r = r1;
		double p1 = xy.x;
		double p2 = xy.y;
		for (int i = 0; i < count; ++i)
		{
			p1 = xy.x + r * xscale;
			p2 = xy.y - f(r)*yscale;
			add(Point(p1, p2));
			r += dist;
		}
	}

	// -----------------------------------------------------------------------------

	Function::Function(std::function<double(double)>f, double r1, double r2, Point xy, int count, double xscale, double yscale)
		// graph f(x) for x in [r1:r2) using count line segments with (0,0) displayed at xy
		// x coordinates are scaled by xscale and y coordinates scaled by yscaleChapter 15 // Exercise 2 - Principles & Practice Using C++
	{
		if (r2 - r1 <= 0) error("bad graphing range");
		if (count <= 0) error("non-positive graphing count");
		double dist = (r2 - r1) / count;
		double r = r1;
		for (int i = 0; i < count; ++i)
		{
			add(Point(xy.x + int(r*xscale), xy.y - int(f(r)*yscale)));
			r += dist;
		}
	}

	// -----------------------------------------------------------------------------

	void StoredFct::init(std::function<double(double)>f, double r1, double r2, Point orig, int count, double xscale, double yscale)
	{
		if (number_of_points() > 0)
		{
			if (r2 - r1 <= 0) error("bad graphing range");
			if (count <= 0) error("non-positive graphing count");

			resetPoints();
			double dist = (r2 - r1) / count;
			double r = r1;
			for (int i = 0; i < count; ++i)
			{
				add(Point(orig.x + int(r*xscale), orig.y - int(f(r)*yscale)));
				r += dist;
			}
		}
	}

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------