// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Circle.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	//------------------------------------------------------------------------------

	void Circle::draw_lines() const
	{
		if (fill_color().visibility())
		{	// fill
			fl_color(fill_color().as_int());
			fl_pie(int(point(0).x), int(point(0).y), r + r - 1, r + r - 1, 0, 360);
			fl_color(color().as_int());	// reset color
		}

		if (color().visibility())
		{
			fl_color(color().as_int());
			fl_arc(int(point(0).x), int(point(0).y), r + r, r + r, 0, 360);
		}
	}

	// -----------------------------------------------------------------------------

	Point Circle::getPointOnCircle(double angle) const
	{
		Point p;
		double rad = angle * (PI / 180.0f);
		p.x = r * cos(rad) + center().x;
		p.y = r * sin(rad) + center().y;
		return p;
	}

	// -----------------------------------------------------------------------------

	Point Circle::getPointDirection(Directions d)
	{
		Point c = center();
		switch (d)
		{
		case NW:
			return getPointOnCircle(135);
		case N:
			return Point(c.x, c.y - r);
		case NE:
			return getPointOnCircle(45);
		case E:
			return Point(c.x + r, c.y);
		case SE:
			return getPointOnCircle(315);
		case S:
			return Point(c.x, c.y + r);
		case SW:
			return getPointOnCircle(225);
		case W:
			return Point(c.x - r, c.y);
		case CENTER:
			return center();
		default:
			error("That's an odd direction");
			return Point(0, 0);
		}
	}

	//------------------------------------------------------------------------------

	void Striped_circle::validateCircle()
	{
		if (m_stripeWidth > (radius() * 2))
			error("Stripe width cannot be more than diameter.");
		if (m_stripeWidth < 1)
			error("Stripe width must be at least 1 pixel wide.");
	}

	// -----------------------------------------------------------------------------

	void Striped_circle::draw_lines() const
	{
		//striped fill
		//how many lines can we have?
		const int numOfLines = (diam() / m_stripeWidth) / 2;
		const int centerX = int(center().x);
		const int centerY = int(center().y);
		const int rad = radius();

		//set the colour for the lines(fill)
		fl_color(fill_color().as_int());

		//Y pos of first line starts at center - radius
		int lineYpos = centerY - rad;
		for (int i = 0; i < numOfLines; ++i)
		{
			for (int n = 0; n < m_stripeWidth; ++n)
			{
				int y = centerY - lineYpos;			//length of y, not position
				int x = int(getSqrt(rad*rad - y * y));	//length of x, not position
				fl_line(centerX - x, lineYpos, centerX + x, lineYpos);	//now calculate co-ordinates
				++lineYpos;							//increase for every line we draw
			}
			//skip stripe width
			lineYpos += m_stripeWidth;
		}

		//outline
		if (color().visibility())
		{
			fl_color(color().as_int());
			fl_arc(int(point(0).x), int(point(0).y), diam() + 1, diam() + 1, 0, 360);
		}
	}

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------