// -----------------------------------------------------------------------------
#ifndef LINE_H_
#define LINE_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Shape.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	// single line - no ability to add more to the shape
	struct Line : Shape
	{
		Line(Point p1, Point p2) { add(p1); add(p2); }
	};

	// -----------------------------------------------------------------------------

	// independent lines - grouped into one shape - can add more
	struct Lines : Shape
	{
		Lines() {}

		Lines(initializer_list<Point> lst)
			: Shape{ lst }
		{
			if (lst.size() % 2)
				error("odd number of points for Lines");
		}

		void draw_lines() const;
		void add(Point p1, Point p2) { Shape::add(p1); Shape::add(p2); }
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !LINE_H_