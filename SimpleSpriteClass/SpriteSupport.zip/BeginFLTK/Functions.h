// -----------------------------------------------------------------------------
#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Shape.h"

#include <functional>

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------
	
	typedef double Fct(double);

	// -----------------------------------------------------------------------------

	struct Function : Shape
	{
		// the function parameters are not stored
		Function(Fct f, double r1, double r2, Point orig, int count = 100, double xscale = 25, double yscale = 25);
		Function(std::function<double(double)>f, double r1, double r2, Point orig, int count = 100, double xscale = 25, double yscale = 25);
	};

	// -----------------------------------------------------------------------------

	struct StoredFct : Function
	{
	public:
		StoredFct(std::function<double(double)>f, double r1, double r2, Point orig, int count = 100, double xscale = 25, double yscale = 25)
			: Function(f, r1, r2, orig, count, xscale, yscale)
			, m_function(f)
			, m_minRange(r1)
			, m_maxRange(r2)
			, m_origin(orig)
			, m_axisLength(count)
			, m_xscale(xscale)
			, m_yscale(yscale)
		{}

		// resets all stored values
		void init(std::function<double(double)>f, double r1, double r2, Point orig, int count = 100, double xscale = 25, double yscale = 25);

	private:
		std::function<double(double)> m_function;
		Point m_origin;
		double m_minRange, m_maxRange;
		double m_xscale, m_yscale;
		int m_axisLength;
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !FUNCTIONS_H_