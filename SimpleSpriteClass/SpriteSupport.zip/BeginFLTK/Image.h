// -----------------------------------------------------------------------------
#ifndef IMAGE_H_
#define IMAGE_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Text.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct Bad_image : Fl_Image
	{
		Bad_image(int h, int w) : Fl_Image(h, w, 0) { }
		void draw(int x, int y, int, int, int, int) { draw_empty(x, y); }
	};

	// -----------------------------------------------------------------------------

	struct Suffix
	{
		enum Encoding { none, jpg, gif, bmp, png };
	};

	Suffix::Encoding get_encoding(const string& s);

	// -----------------------------------------------------------------------------

	struct Image : Shape
	{
		Image(Point xy, string s, Suffix::Encoding e = Suffix::none);
		~Image() { delete p; }
		void draw_lines() const;
		void set_mask(Point xy, int ww, int hh) { w = ww; h = hh; cx = int(xy.x); cy = int(xy.y); }
		void move(double dx, double dy) { Shape::move(int(dx), int(dy)); p->draw(int(point(0).x), int(point(0).y)); }
		void changePoint(double x, double y) { Shape::set_point(0, Point{ x, y }); }
		double getWidth() { return p->w(); }
		double getHeight() { return p->h(); }
	private:
		int w, h, cx, cy; // define "masking box" within image relative to position (cx,cy)
		Fl_Image* p;
		Text fn;
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !IMAGE_H_
