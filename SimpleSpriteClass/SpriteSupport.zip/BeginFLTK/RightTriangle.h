// -----------------------------------------------------------------------------
#ifndef RIGHTTRIANGLE_H_
#define RIGHTTRIANGLE_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Polygon.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct RightTriangle : Polygon
	{
		// p2 must be right-angle point (otherwise it may error)
		RightTriangle(Point p1, Point p2, Point p3)
		{
			Polygon::add(p1);
			Polygon::add(p2);
			Polygon::add(p3);
			validateTriangle(p1, p2, p3);
		}

		RightTriangle(Point p1, Point p2, Point p3, Graph_lib::Color fill, Graph_lib::Color outline = Color::magenta)
			: RightTriangle(p1, p2, p3)
		{
			set_color(outline);
			set_fill_color(fill);
		}

		void draw_lines() const { Polygon::draw_lines(); }

		static double findAngleBetween2Lines(Point beginLine1, Point endLine1, Point beginLine2, Point endLine2)
		{
			double angle1 = abs(atan2(beginLine1.y - endLine1.y, beginLine1.x - endLine1.x));
			double angle2 = abs(atan2(beginLine2.y - endLine2.y, beginLine2.x - endLine2.x));

			return abs(angle1 - angle2)*(180 / PI);
		}

		static void rightTriangleTileWindow(vector<RightTriangle>& v, int sideLength);

	private:
		void validateTriangle(Point p1, Point p2, Point p3);

		double a1, a2, a3;
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !RIGHTTRIANGLE_H_
