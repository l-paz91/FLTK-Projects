// -----------------------------------------------------------------------------
#ifndef REGULARPOLYGON_H_
#define REGULARPOLYGON_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Polygon.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	// a Polygon whose sides must all be the same length
	struct Regular_polygon : Polygon
	{
		Regular_polygon(Point center, double radius, int numOfSides, double rotate = 0)
		{
			m_numSides = numOfSides;
			m_radius = radius;
			m_apothem = radius * cos(PI / numOfSides);
			m_sideLength = radius + radius * sin(PI / numOfSides);

			for (int i = 0; i < numOfSides; ++i)
			{
				double x = radius * cos(2 * PI * i / numOfSides + rotate) + center.x;
				double y = radius * sin(2 * PI * i / numOfSides + rotate) + center.y;
				Polygon::add(Point{ x, y });
			}
		}

		void draw_lines() const { Polygon::draw_lines(); }
	private:
		using Shape::set_point;
		using Shape::add;

		int m_numSides;
		double m_sideLength, m_radius, m_apothem;
	};

	// -----------------------------------------------------------------------------

	struct Regular_Hexagon : Regular_polygon
	{
		Regular_Hexagon(Point center, double radius)
			: Regular_polygon(center, radius, 6)
		{}

		Regular_Hexagon(Point center, double radius, Graph_lib::Color fill, Graph_lib::Color outline = Color::black)
			: Regular_Hexagon(center, radius)
		{
			set_color(outline);
			set_fill_color(fill);
		}

		void draw_lines() const;
		static void hexagonTile(vector<Regular_Hexagon>& v, int numHex, int radius, int widthTile, Point p);

	private:
		using Shape::set_point;
		using Shape::add;
	};

	// -----------------------------------------------------------------------------

	struct Regular_Octagon : Regular_polygon
	{
		Regular_Octagon(Point center, double radius)
			: Regular_polygon(center, radius, 8)
		{}

		Regular_Octagon(Point center, double radius, Graph_lib::Color fill, Graph_lib::Color outline = Color::black)
			: Regular_Octagon(center, radius)
		{
			set_color(outline);
			set_fill_color(fill);
		}

		void draw_lines() const;

	private:
		using Shape::set_point;
		using Shape::add;
	};

	// -----------------------------------------------------------------------------

	struct EquilateralTriangle : Regular_polygon
	{
		EquilateralTriangle(Point center, double radius)
			: Regular_polygon(center, radius, 3, 0.523599) //awful magic number...30 degrees
		{
			set_color(Color::black);
		}

		void draw_lines() const { Polygon::draw_lines(); }
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !REGULARPOLYGON_H_
