// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Rectangle.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------
	
	void Rectangle::draw_lines() const
	{
		if (fill_color().visibility())
		{	// fill
			fl_color(fill_color().as_int());
			fl_rectf(int(point(0).x), int(point(0).y), int(w), int(h));
			fl_color(color().as_int());	// reset color
		}

		if (color().visibility())
		{	// edge on top of fill
			fl_color(color().as_int());
			fl_rect(int(point(0).x), int(point(0).y), int(w), int(h));
		}
	}

	// -----------------------------------------------------------------------------

	Point Rectangle::getPointDirection(Directions d)
	{
		switch (d)
		{
		case NW:
			return point(0);
		case N:
			return Point(point(0).x + (w / 2), point(0).y);
		case NE:
			return Point(point(0).x + w, point(0).y);
		case E:
			return Point(point(0).x + w, point(0).y + (h / 2));
		case SE:
			return Point(point(0).x + w, point(0).y + h);
		case S:
			return Point(point(0).x + (w / 2), point(0).y + h);
		case SW:
			return Point(point(0).x, point(0).y + h);
		case W:
			return Point(point(0).x, point(0).y + (h / 2));
		case CENTER:
			return Point(point(0).x + (w / 2), point(0).y + (h / 2));
		default:
			error("That's an odd direction");
			return Point(0, 0);
		}
	}

	//------------------------------------------------------------------------------


}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------