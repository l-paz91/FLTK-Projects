// -----------------------------------------------------------------------------
#ifndef BOX_H_
#define BOX_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Shape.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct Box : Shape
	{
		Box(Point p, int ww, int hh, int cornerRoundAmount)
			: w{ ww }
			, h{ hh }
			, round{ cornerRoundAmount }
		{
			if ((w - cornerRoundAmount < 0) || (h - cornerRoundAmount < 0))
				error("roundness cannot exceed given height/width");
			add(Point{ p.x, p.y });
		}

		void draw_lines() const;
		void change_roundAmount(int cornerRoundAmount)
		{
			if ((w - cornerRoundAmount < 0) || (h - cornerRoundAmount < 0))
				error("roundness cannot exceed given height/width");
			else
				round = cornerRoundAmount;
		}
		int getWidth() const { return w; };
		int getLength() const { return h; }

	private:
		int w, h;
		int round;
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !BOX_H_
