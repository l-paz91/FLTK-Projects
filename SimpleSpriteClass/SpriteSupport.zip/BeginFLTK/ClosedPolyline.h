// -----------------------------------------------------------------------------
#ifndef CLOSEDPOLYLINE_H_
#define CLOSEDPOLYLINE_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "OpenPolyline.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	// closed sequence of lines
	struct Closed_polyline : Open_polyline
	{
		using Open_polyline::Open_polyline;
		Closed_polyline() {}

		Closed_polyline(initializer_list<Point> p)
			: Open_polyline(p)
		{}

		void draw_lines() const;
	};

	// -----------------------------------------------------------------------------

	struct Striped_closed_polyline : Closed_polyline
	{
		using Closed_polyline::Closed_polyline;

		Striped_closed_polyline(initializer_list<Point> p)
			: Closed_polyline(p)
		{
			m_stripeWidth = 1;
			add(Point{ point(0).x, point(0).y }); //close shape & prevent intersection shenanigans
		}

		void setStripeWidth(int width) { m_stripeWidth = width; }

		void draw_lines() const;

	private:
		int m_stripeWidth;
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

#endif // !CLOSEDPOLYLINE_H_
