// -----------------------------------------------------------------------------
#ifndef POINT_GUARD
#define POINT_GUARD

// -----------------------------------------------------------------------------

namespace Graph_lib 
{
	// -----------------------------------------------------------------------------

	struct Point 
	{
		// ----Constructors
		Point(double xx, double yy) : x(xx), y(yy) { }
		Point() : x(0), y(0) { }

		// ----Members
		double x,y;

		// ----Helpers
		Point& operator+=(Point d) { x+=d.x; y+=d.y; return *this; }
	};

	inline bool operator==(Point a, Point b) { return a.x==b.x && a.y==b.y; }

	inline bool operator!=(Point a, Point b) { return !(a==b); }

	inline bool compareByX(const Point& a, const Point& b) { return a.x < b.x; }

	inline bool compareByY(const Point& a, const Point& b) { return a.y < b.y; }

	// -----------------------------------------------------------------------------
	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !POINT_GUARD