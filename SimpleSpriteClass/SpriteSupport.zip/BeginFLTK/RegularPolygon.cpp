// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "RegularPolygon.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	//------------------------------------------------------------------------------

	void Regular_Hexagon::draw_lines() const
	{
		if (number_of_points() < 6)
			error("less than 6 points in a Hexagon");
		Polygon::draw_lines();
	}

	// -----------------------------------------------------------------------------

	void Regular_Hexagon::hexagonTile(vector<Regular_Hexagon>& v, int numHex, int radius, int widthTile, Point p)
	{
		double twoR = radius + radius;
		double sideLength = twoR * sin(PI / 6);
		double edge = p.x + widthTile;
		double apothem = radius * cos(PI / 6);
		bool flipflop = 0;

		for (int i = 0; i < numHex; ++i)
		{
			Regular_Hexagon hex(p, radius);
			hex.set_color(Color::black);
			hex.set_fill_color(i);
			v.push_back(hex);
			p.x += twoR + sideLength;
			if (p.x > edge)
			{
				flipflop = !flipflop;
				p.x = flipflop * (radius + (sideLength / 2));
				p.y += apothem;
			}
		}
	}

	//------------------------------------------------------------------------------

	void Regular_Octagon::draw_lines() const
	{
		if (number_of_points() < 8)
			error("less than 8 points in an Octagon");
		Polygon::draw_lines();
	}

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------