// -----------------------------------------------------------------------------
#ifndef MARK_H_
#define MARK_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "OpenPolyline.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct Mark : Shape
	{
		Mark(Point p, char m, Graph_lib::Color c)
			: mark(string(1, m))
		{
			add(p);
			set_color(c);
		}

		Mark(char m) :
			mark(string(1, m))
		{ }

		void add(Point p) { Shape::add(p); }
		void set_point(int i, Point p) { Shape::set_point(i, p); }
		void draw_lines() const;

	private:
		string mark;
	};

	// -----------------------------------------------------------------------------

	struct Marked_polyline : Open_polyline
	{
		Marked_polyline(const string& m) : mark(m) { }
		void draw_lines() const;
	private:
		string mark;
	};

	// -----------------------------------------------------------------------------

	struct Marks : Marked_polyline
	{
		Marks(const string& m) :Marked_polyline(m)
		{
			set_color(Color(Color::invisible));
		}
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !MARK_H_
