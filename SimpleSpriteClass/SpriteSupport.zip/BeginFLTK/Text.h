// -----------------------------------------------------------------------------
#ifndef TEXT_H_
#define TEXT_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Box.h"
#include "Shape.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct Text : Shape
	{
		// the point is the bottom left of the first letter
		Text() {}	//default constructor
		Text(Point x, const string& s) : lab{ s }
		{
			//initialise the font face
			set_font(Font::helvetica);
			set_font_size(14); //14 is default FLTK size
			fl_font(fnt.as_int(), fnt_sz);
			add(x);
		}

		void draw_lines() const;

		void set_label(const string& s) { lab = s; }
		string label() const { return lab; }

		void set_font(Font f) { fnt = f; }
		Font font() const { return Font(fnt); }

		void set_font_size(int s) { fnt_sz = s; }
		int font_size() const { return fnt_sz; }

		//length of text message
		double length() { return fl_width(lab.c_str()); }

	private:
		string lab;	// label
		Font fnt{ fl_font() };
		int fnt_sz{ (14 < fl_size()) ? fl_size() : 14 };	// at least 14 point
	};

	// -----------------------------------------------------------------------------

	struct TextBox : Text
	{
		TextBox(Point p, string msg, int cornerRoundAmount)
			: Text(Point(p.x + double(10.0), p.y + double(20.0)), msg)
			, box(p, int(length()) + 20, font_size() + 20, cornerRoundAmount)
		{}

		void setColours(Color boxOutline, Color boxFill, Color textColor);
		void draw_lines() const;

		Point getTopCenter()    const { return Point{ box.point(0).x + box.getWidth()*0.5, box.point(0).y }; }
		Point getBottomCenter() const { return Point{ box.point(0).x + box.getWidth()*0.5 , box.point(0).y + box.getLength() }; }
		Point getLeftCenter()   const { return Point{ box.point(0).x, box.point(0).y + (box.getLength()*0.5) }; }
		Point getRightCenter()  const { return Point{ box.point(0).x + box.getWidth(), box.point(0).y + (box.getLength()*0.5) }; }

		int getW() const { return box.getWidth(); }
		int getH() const { return box.getLength(); }

		Box box;
	private:
		string message;
	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !TEXT_H_