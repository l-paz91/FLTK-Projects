// -----------------------------------------------------------------------------
#ifndef AXIS_H_
#define AXIS_H_
// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Line.h"
#include "Shape.h"
#include "Text.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	// -----------------------------------------------------------------------------

	struct Axis : Shape
	{
	public:
		// representation left public
		enum Orientation { x, y, z };
		Axis(Orientation d, Point xy, int length, int nummber_of_notches = 0, string label = "");

		void draw_lines() const;
		void move(int dx, int dy);
		void setLabel(string s) { label.set_label(s); }
		void set_color(Color c);
		void setNotches(int numNotches, Orientation d) { m_numNotches = numNotches; setNotches(d); }
		Lines gn() const { return notches; }
		Point getNotch(int i) const { return notches.point(i); }

	private:
		void setNotches(Orientation d);

		Point m_xy;
		Text label;
		Lines notches;
		Orientation m_o;
		int m_numNotches, m_length;

	};

	// -----------------------------------------------------------------------------

}	// END namespace Graph_lib
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#endif // !AXIS_H_