// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Ellipse.h"

// -----------------------------------------------------------------------------

namespace Graph_lib
{
	//------------------------------------------------------------------------------

	void Ellipse::draw_lines() const
	{
		if (fill_color().visibility())
		{	// fill
			fl_color(fill_color().as_int());
			fl_pie(int(point(0).x), int(point(0).y), w + w - 1, h + h - 1, 0, 360);
			fl_color(color().as_int());	// reset color
		}

		if (color().visibility())
		{
			fl_color(color().as_int());
			fl_arc(int(point(0).x), int(point(0).y), w + w, h + h, 0, 360);
		}
	}

	// -----------------------------------------------------------------------------

	Point Ellipse::getPointOnEllipse(int angle)
	{
		Point p;
		double rad = angle * (PI / 180.0f);
		p.x = w * cos(rad) + center().x;
		p.y = h * sin(rad) + center().y;
		return p;
	}

	// -----------------------------------------------------------------------------

	Point Ellipse::getPointDirection(Directions d)
	{
		Point c = center();
		switch (d)
		{
		case NW:
			return getPointOnEllipse(135);
		case N:
			return Point(c.x, c.y - h);
		case NE:
			return getPointOnEllipse(45);
		case E:
			return Point(c.x + w, c.y);
		case SE:
			return getPointOnEllipse(315);
		case S:
			return Point(c.x, c.y + h);
		case SW:
			return getPointOnEllipse(225);
		case W:
			return Point(c.x - w, c.y);
		case CENTER:
			return center();
		default:
			error("That's an odd direction");
			return Point(0, 0);
		}
	}

	//------------------------------------------------------------------------------

}	// END namespace Graph_lib

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------